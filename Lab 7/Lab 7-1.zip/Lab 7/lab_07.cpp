//================================================================
// Filename: lab_07.cpp
// Author: Ryan Ellis
// Creation Date: 3/25/2025
// Last Update: 
// Description: 
// User Interface: 
// Notes: 
//================================================================

#include <iostream>
#include "d_hash.h"
#include "d_hashf.h"
#include <fstream> 

using namespace std;

ifstream& getWord(ifstream& fin, string& w);

int main(){

    ifstream inputFile;
    string filename = "";
    int numBuckets = 1373;
    hFstring stringHash;
    myhash<string, hFstring> table(numBuckets, stringHash);
    
    
    
    inputFile.open("dict.dat");
    if(inputFile){
        string line;
        while(getline(inputFile,line)){
            table.insert(line);
        }
    }
    
    inputFile.close();
    
    cout<<"Enter the document name: ";
    cin>>filename;
    
    if(filename.find(".txt") == string::npos)
        filename = filename + ".txt";
    
    inputFile.open(filename);
    
    if(inputFile){
        string line;
        while(getline(inputFile, line)){
            getWord(inputFile, line);
            
        }
        
    }
    else{
        cerr<<"Error opening the file.\n";
        
    }
    
    
    
    return 0;
}

//extract a word from fin
ifstream& getWord(ifstream& fin, string& w)
{
	char c;

	w = "";	// clear the string of characters

	while (fin.get(c) && !isalpha(c))
		;	// do nothing. just ignore c

	// return on end-of-file
	if (fin.eof())
		return fin;

	// record first letter of the word
	w += tolower(c);

	// collect letters and digits
	while (fin.get(c) && (isalpha(c) || isdigit(c)))
		w += tolower(c);

	return fin;
}

