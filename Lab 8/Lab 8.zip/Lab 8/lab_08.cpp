//================================================================
// Filename: lab_08.cpp
// Author: Ryan Ellis
// Creation Date: 4/1/2025
// Last Update: 
// Description: 
// User Interface: 
// Notes: 
//================================================================

#include "d_except.h"
#include "d_pqueue.h"
#include "d_heap.h"
#include "preqrec.h"
#include <iostream>
#include <functional>
#include <ctime>

using namespace std;

int main (){
    
    srand(time(0));
    
    const int INTRANGE = 39;
    string alpha[10] = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J"};
    
    miniPQ<procReqRec, less<procReqRec>> mpq;
    
    for(int i = 0; i < 10; i++){
        
        int randP = rand()% + INTRANGE;
        procReqRec proc("Process " + alpha[i], randP);
        mpq.push(proc);
        
    }
    
    while (!mpq.empty()){
        
        cout<<mpq.top()<<endl;
        mpq.pop();
        
    }

    return 0;
}
