#ifndef PROCESSREQUESTRECORD_CLASS
#define PROCESSREQUESTRECORD_CLASS

#include <iostream>
#include <string>

using namespace std;

class procReqRec
{
	public:
		// default constructor
		procReqRec()
		{}

		// constructor
		procReqRec(const string& nm, int p);

		// access functions
		int getPriority();
		string getName();

		// update functions
		void setPriority(int p);
		void setName(const string& nm);

		// for maintenance of a minimum priority queue
		friend bool operator< (const procReqRec& left,
			const procReqRec& right);

		// output a process request record in the format
		//   name: priority
		friend ostream& operator<< (ostream& ostr,
	const procReqRec& obj);

	private:
		string name;	// process name
		int priority;	// process priority
};

//====================================================
// Description: <One paragraph describing what the function does>
// Parameters: <List of parameters and their descriptions>
// Return: <What is returned by the function, if anything is returned>
// Notes: <Any notes that a user of the program should know about, e.g. pre/post conditions>
//====================================================
procReqRec :: procReqRec(const string& nm, int p){
    name = nm;
    priority = p;
    
}

//====================================================
// Description: <One paragraph describing what the function does>
// Parameters: <List of parameters and their descriptions>
// Return: <What is returned by the function, if anything is returned>
// Notes: <Any notes that a user of the program should know about, e.g. pre/post conditions>
//====================================================
int procReqRec :: getPriority(){
    return priority;
    
}

//====================================================
// Description: <One paragraph describing what the function does>
// Parameters: <List of parameters and their descriptions>
// Return: <What is returned by the function, if anything is returned>
// Notes: <Any notes that a user of the program should know about, e.g. pre/post conditions>
//====================================================
string procReqRec :: getName(){
    return name;
    
}

//====================================================
// Description: <One paragraph describing what the function does>
// Parameters: <List of parameters and their descriptions>
// Return: <What is returned by the function, if anything is returned>
// Notes: <Any notes that a user of the program should know about, e.g. pre/post conditions>
//====================================================
void procReqRec :: setName(const string& nm){
    name = nm;
    
}

//====================================================
// Description: <One paragraph describing what the function does>
// Parameters: <List of parameters and their descriptions>
// Return: <What is returned by the function, if anything is returned>
// Notes: <Any notes that a user of the program should know about, e.g. pre/post conditions>
//====================================================
void procReqRec :: setPriority(int p){

    priority = p;
}

//====================================================
// Description: <One paragraph describing what the function does>
// Parameters: <List of parameters and their descriptions>
// Return: <What is returned by the function, if anything is returned>
// Notes: <Any notes that a user of the program should know about, e.g. pre/post conditions>
//====================================================
bool operator<(const procReqRec& left, const procReqRec& right){
    bool status;
    
    if(left.priority < right.priority)
        status = true;
    else
        status = false;
    return status;
    
}

//====================================================
// Description: <One paragraph describing what the function does>
// Parameters: <List of parameters and their descriptions>
// Return: <What is returned by the function, if anything is returned>
// Notes: <Any notes that a user of the program should know about, e.g. pre/post conditions>
//====================================================
ostream& operator<< (ostream& ostr,const procReqRec& obj){
    ostr<< obj.name<<" : "<<obj.priority;
    return ostr;
    
}
#endif	// PROCESSREQUESTRECORD_CLASS
